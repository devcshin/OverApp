package com.icyfruits.overapp;

import android.support.v4.app.Fragment;

/**
 * Created by m09-5 on 2016-10-18.
 */

public class DummyFragment extends Fragment {
}
