package com.icyfruits.overapp;

/**
 * Created by m09-5 on 2016-11-28.
 */

public class G {

    public static String check=new String("");
    public static String checkname=new String("");

    public static int count;
}
